package com;

public class Signupgs {

	public void setEmail(String email) {
		// TODO Auto-generated method stub
		
	}

	public void setPassword(String password) {
		// TODO Auto-generated method stub
		
	}

}
