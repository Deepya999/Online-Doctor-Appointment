package com;

public class Feedbackgs {

	public void setcomments(String comments) {
		// TODO Auto-generated method stub
		
	}

}
