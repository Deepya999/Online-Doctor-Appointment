package com;

public @interface Webservlet {

	String value();

	

}
