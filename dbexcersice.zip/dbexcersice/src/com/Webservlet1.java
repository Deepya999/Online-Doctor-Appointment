package com;

public @interface Webservlet1 {

	String value();

}
