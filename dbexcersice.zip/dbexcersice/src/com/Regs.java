package com;

public class Regs {

	public void setFirstname(String firstname) {
		// TODO Auto-generated method stub

	}

	public void setMiddlename(String middlename) {
		// TODO Auto-generated method stub

	}

	public void setLastname(String lastname) {
		// TODO Auto-generated method stub

	}

	public void setGender(String gender) {
		// TODO Auto-generated method stub

	}

	public void setPhone(String phone) {
		// TODO Auto-generated method stub

	}

	public void setEmail(String email) {
		// TODO Auto-generated method stub

	}

	public void setDate_of_appointment(String date_of_appointment) {
		// TODO Auto-generated method stub

	}

	public void setChoose_patient(String choose_patient) {
		// TODO Auto-generated method stub

	}

	public void setDepartment(String department) {
		// TODO Auto-generated method stub

	}


}