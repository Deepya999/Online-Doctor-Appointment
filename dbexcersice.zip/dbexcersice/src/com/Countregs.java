package com;















import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;















import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;







@Webservlet("Countregs")
public class Countregs extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("1");

		System.out.println("2");

		DoctorPagegs c=new DoctorPagegs();


		System.out.println("3");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("4");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("5");
			PreparedStatement st=con.prepareStatement( "select count(*) from regs");
			System.out.println("6");

			System.out.println("7");
			PrintWriter pw=response.getWriter();
			System.out.println("8");
			int rs = st.executeUpdate();
			System.out.println(rs);
			if(rs>0){
				con.commit();
				pw.println("datasaved successfully");
				response.sendRedirect("Link1.html");
			}
			else{
				response.sendRedirect("Userlogin.html");
			} 
































		}
		catch(Exception e){
			System.out.println(e);
		}
	}









}