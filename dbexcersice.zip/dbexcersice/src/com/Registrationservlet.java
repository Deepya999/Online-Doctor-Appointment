package com;















import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;















import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;







@Webservlet1("Registrationservlet")
public class Registrationservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("1");
		int count=0;
		String Firstname  = request.getParameter("Firstname");
		String Middlename = request.getParameter("Middlename");
		String Lastname = request.getParameter("Lastname");
		String Gender  = request.getParameter("gender");
		String Phone = request.getParameter("Phone");
		String Email = request.getParameter("Email");
		String Date_of_appointment = request.getParameter("Date_of_appointment");
		String Choose_patient= request.getParameter("Choose_patient");
		String Department= request.getParameter("dep");



		System.out.println("2");

		Regs c=new Regs();

		c.setFirstname(Firstname);
		c.setMiddlename(Middlename);
		c.setLastname(Lastname);
		c.setGender(Gender);
		c.setPhone(Phone);
		c.setEmail(Email);
		c.setDate_of_appointment(Date_of_appointment);
		c.setChoose_patient(Choose_patient);
		c.setDepartment(Department);





		System.out.println("3");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("4");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("5");
			PreparedStatement st=con.prepareStatement( "insert into regs values(?,?,?,?,?,?,?,?,?) ");
			System.out.println("6");
			st.setString(1, Firstname);
			st.setString(2, Middlename);
			st.setString(3, Lastname);
			st.setString(4, Gender);
			st.setString(5, Phone);
			st.setString(6, Email);
			st.setString(7, Date_of_appointment);
			st.setString(8, Choose_patient);
			st.setString(9, Department);








			System.out.println("7");
			PrintWriter pw=response.getWriter();
			System.out.println("8");
			int rs = st.executeUpdate();
			System.out.println(rs);
			if(rs>0){
				con.commit();
				pw.println("datasaved successfully");
				response.sendRedirect("RegistrationSucess.html");
			}
			else{
				response.sendRedirect("UserRegistration.html");
			} 












			pw.close();
			st.close();
			con.close();






























		}
		catch(Exception e){
			System.out.println(e);
		}
	}















}