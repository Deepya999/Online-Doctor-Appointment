package com;

public class DoctorPagegs {

}
