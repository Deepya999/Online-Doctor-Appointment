package com;

public class Filegs {

	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}

	public void setAadharid(String aadharid) {
		// TODO Auto-generated method stub
		
	}

	public void setCity(String city) {
		// TODO Auto-generated method stub
		
	}

	public void setState(String state) {
		// TODO Auto-generated method stub
		
	}

	public void setPincode(String pincode) {
		// TODO Auto-generated method stub
		
	}

	public void setNoofdependencies(String noofdependencies) {
		// TODO Auto-generated method stub
		
	}

}
