package com;















import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;















import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;







@Webservlet1("MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("1");
		int count=0;
		String name = request.getParameter("name");
		String Aadharid = request.getParameter("Aadharid");
		String city = request.getParameter("city");
		String state  = request.getParameter("state");
		String pincode = request.getParameter("pincode");
		String noofdependencies = request.getParameter("noofdependencies");
		System.out.println("2");

		Filegs c=new Filegs();

		c.setName(name);
		c.setAadharid(Aadharid);
		c.setCity(city);
		c.setState(state);
		c.setPincode(pincode);
		c.setNoofdependencies(noofdependencies);
		System.out.println("3");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("4");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("5");
			PreparedStatement st=con.prepareStatement( "insert into details values(?,?,?,?,?,?,) ");
			System.out.println("6");
			st.setString(1, name);
			st.setString(2, Aadharid);
			st.setString(3, city);
			st.setString(4, state);
			st.setString(5, pincode);
			st.setString(6, noofdependencies);
			System.out.println("7");
			PrintWriter pw=response.getWriter();
			System.out.println("8");
			int rs = st.executeUpdate();
			System.out.println(rs);
			if(rs>0){
				con.commit();
				pw.println("datasaved successfully");
				response.sendRedirect("NewFile1.html");
			}
			else{
				response.sendRedirect("UserRegistration.html");
			} 












			pw.close();
			st.close();
			con.close();






























		}
		catch(Exception e){
			System.out.println(e);
		}
	}















}















